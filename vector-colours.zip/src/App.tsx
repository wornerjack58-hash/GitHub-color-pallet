import { useState, useEffect, useMemo, MouseEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Copy,
  Check,
  Star,
  Search,
  Sliders,
  Eye,
  RefreshCw,
  Plus,
  Trash2,
  SlidersHorizontal,
  FolderHeart,
  Palette,
  Layers,
  Sparkles,
  Info,
  Grid2X2,
  Grid3X3,
  List
} from 'lucide-react';

import {
  PRESET_GRADIENTS,
  PRESET_PALETTES,
  GradientItem,
  PaletteItem,
  generateRandomGradient,
  generateRandomPalette,
  generateRandomAestheticColor
} from './data/colorData';

export default function App() {
  // Navigation tabs
  const [currentTab, setCurrentTab] = useState<'gradients' | 'combinations' | 'sandbox' | 'favorites'>('gradients');
  
  // Custom states
  const [tagFilter, setTagFilter] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [gridSize, setGridSize] = useState<'compact' | 'normal' | 'large'>('normal');
  
  // Dynamic color lists with built-in curated presets
  const [gradients, setGradients] = useState<GradientItem[]>(PRESET_GRADIENTS);
  const [palettes, setPalettes] = useState<PaletteItem[]>(PRESET_PALETTES);

  // Favorites state loaded from localStorage
  const [favGradients, setFavGradients] = useState<GradientItem[]>(() => {
    const saved = localStorage.getItem('vc_fav_gradients');
    return saved ? JSON.parse(saved) : [];
  });
  const [favPalettes, setFavPalettes] = useState<PaletteItem[]>(() => {
    const saved = localStorage.getItem('vc_fav_palettes');
    return saved ? JSON.parse(saved) : [];
  });

  // Selected item specifically for the Sandbox preview section
  const [sandboxGradient, setSandboxGradient] = useState<GradientItem>(PRESET_GRADIENTS[0]);
  const [sandboxPalette, setSandboxPalette] = useState<PaletteItem>(PRESET_PALETTES[0]);
  
  // Custom creator states inside the Sandbox / Editor tab
  const [customStart, setCustomStart] = useState<string>('#3b82f6');
  const [customEnd, setCustomEnd] = useState<string>('#ec4899');
  const [customAngle, setCustomAngle] = useState<number>(135);

  // Items shown for pagination/infinite scroll
  const [itemsShown, setItemsShown] = useState<number>(12);

  // AI color generation states
  const [aiGeneratedPalette, setAiGeneratedPalette] = useState<{
    paletteName: string;
    colors: string[];
    relationshipType: string;
    baseColor: string;
  } | null>(null);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [showAIPanel, setShowAIPanel] = useState<boolean>(false);

  // Feedbacks toast notifications
  const [toastMessage, setToastMessage] = useState<string>('');
  const [showToast, setShowToast] = useState<boolean>(false);

  // Sync favorites with LocalStorage
  useEffect(() => {
    localStorage.setItem('vc_fav_gradients', JSON.stringify(favGradients));
  }, [favGradients]);

  useEffect(() => {
    localStorage.setItem('vc_fav_palettes', JSON.stringify(favPalettes));
  }, [favPalettes]);

  // Toast helper
  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setShowToast(true);
  };

  useEffect(() => {
    if (showToast) {
      const timer = setTimeout(() => setShowToast(false), 2600);
      return () => clearTimeout(timer);
    }
  }, [showToast]);

  // Copy helper
  const copyText = (text: string, label: string) => {
    navigator.clipboard.writeText(text).then(() => {
      triggerToast(`Copied ${label} to clipboard! 🚀`);
    }).catch(() => {
      triggerToast(`Failed to copy color!`);
    });
  };

  // Switch tabs
  const handleTabSwitch = (tab: 'gradients' | 'combinations' | 'sandbox' | 'favorites') => {
    setCurrentTab(tab);
  };

  // Helper to load items and update itemsShown for infinite scrolling
  const renderItems = () => {
    setItemsShown(prev => {
      const nextVal = prev + 8;
      
      const isGrad = currentTab === 'gradients';
      const tag = tagFilter === 'All' ? undefined : tagFilter;
      
      if (isGrad) {
        if (nextVal > gradients.length) {
          const newItems = Array.from({ length: 8 }, () => generateRandomGradient(tag));
          setGradients(p => [...p, ...newItems]);
        }
      } else {
        if (nextVal > palettes.length) {
          const newItems = Array.from({ length: 8 }, () => generateRandomPalette(tag));
          setPalettes(p => [...p, ...newItems]);
        }
      }
      return nextVal;
    });
  };

  // Reset itemsShown when filters or tab switches
  useEffect(() => {
    setItemsShown(12);
  }, [currentTab, tagFilter, searchQuery]);

  // Infinite Scroll listener effect
  useEffect(() => {
    const handleScroll = () => {
      if (currentTab !== 'gradients' && currentTab !== 'combinations') return;
      
      const scrollHeight = document.documentElement.scrollHeight;
      const scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
      const clientHeight = document.documentElement.clientHeight;
      
      if (scrollHeight - scrollTop - clientHeight < 250) {
        renderItems();
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [currentTab, tagFilter, searchQuery, gradients.length, palettes.length]);

  // AI-powered related colors generator using server-side Gemini API
  const generateRelatedColors = async (hex: string) => {
    if (isGenerating) return;
    setIsGenerating(true);
    setShowAIPanel(true);
    setAiGeneratedPalette(null);
    triggerToast(`Asking Gemini to curate related colors for ${hex}... ✧`);
    
    try {
      const res = await fetch("/api/generate-palette", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ baseColor: hex }),
      });
      if (!res.ok) throw new Error("Server response error");
      const data = await res.json();
      if (data.success && data.palette) {
        setAiGeneratedPalette({
          ...data.palette,
          baseColor: hex,
        });
        triggerToast(`Gemini successfully created "${data.palette.paletteName}"! 🎨`);
      } else {
        throw new Error(data.error || "Failed to generate colors");
      }
    } catch (err: any) {
      console.error(err);
      triggerToast(`AI Error: ${err.message || "Could not call Gemini service"}`);
    } finally {
      setIsGenerating(false);
    }
  };

  // Infinite Generation generator
  const loadMore = () => {
    renderItems();
  };

  // Favorite managers
  const toggleFavGradient = (item: GradientItem, e: MouseEvent) => {
    e.stopPropagation();
    const isFav = favGradients.some(g => g.id === item.id);
    if (isFav) {
      setFavGradients(prev => prev.filter(g => g.id !== item.id));
      triggerToast('Removed from favorites');
    } else {
      setFavGradients(prev => [...prev, item]);
      triggerToast('Saved to your favorites! ❤️');
    }
  };

  const toggleFavPalette = (item: PaletteItem, e: MouseEvent) => {
    e.stopPropagation();
    const isFav = favPalettes.some(p => p.id === item.id);
    if (isFav) {
      setFavPalettes(prev => prev.filter(p => p.id !== item.id));
      triggerToast('Removed from favorites');
    } else {
      setFavPalettes(prev => [...prev, item]);
      triggerToast('Saved to your favorites! ❤️');
    }
  };

  // Quick preset loader to customize
  const loadIntoEditor = (colors: [string, string], angle: number) => {
    setCustomStart(colors[0]);
    setCustomEnd(colors[1]);
    setCustomAngle(angle);
    setCurrentTab('sandbox');
    triggerToast('Loaded colors into editor sandbox! ⚙️');
  };

  // Dynamic filter lists based on search & tag selections
  const filteredGradients = useMemo(() => {
    return gradients.filter(g => {
      const matchesTag = tagFilter === 'All' || g.tags.includes(tagFilter);
      const query = searchQuery.trim().toLowerCase();
      const matchesSearch = !query || 
        g.name.toLowerCase().includes(query) ||
        g.colors.some(c => c.toLowerCase().includes(query)) ||
        g.tags.some(t => t.toLowerCase().includes(query));
      return matchesTag && matchesSearch;
    });
  }, [gradients, tagFilter, searchQuery]);

  const filteredPalettes = useMemo(() => {
    return palettes.filter(p => {
      const matchesTag = tagFilter === 'All' || p.tags.includes(tagFilter);
      const query = searchQuery.trim().toLowerCase();
      const matchesSearch = !query ||
        p.name.toLowerCase().includes(query) ||
        p.colors.some(c => c.toLowerCase().includes(query)) ||
        p.tags.some(t => t.toLowerCase().includes(query));
      return matchesTag && matchesSearch;
    });
  }, [palettes, tagFilter, searchQuery]);

  // Displayed colors lists that obey itemsShown count constraint
  const displayedGradients = useMemo(() => {
    return filteredGradients.slice(0, itemsShown);
  }, [filteredGradients, itemsShown]);

  const displayedPalettes = useMemo(() => {
    return filteredPalettes.slice(0, itemsShown);
  }, [filteredPalettes, itemsShown]);

  // List of active filter tags available in our curated sets
  const tags = ['All', 'Sunset', 'Ocean', 'Forest', 'Pastel', 'Neon', 'Vintage', 'Minimal'];

  // Grid style class definitions
  const gridClasses = useMemo(() => {
    if (gridSize === 'compact') {
      return 'grid-cols-2 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4';
    } else if (gridSize === 'large') {
      return 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8';
    }
    return 'grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6';
  }, [gridSize]);

  // Set selected palette to update the preview sandbox
  const applyPaletteToSandbox = (palette: PaletteItem) => {
    setSandboxPalette(palette);
    // Auto-update custom preset preview color stop starts
    if (palette.colors.length >= 2) {
      setCustomStart(palette.colors[0]);
      setCustomEnd(palette.colors[palette.colors.length - 1]);
    }
    triggerToast(`Applied "${palette.name}" colors to Live Sandbox!`);
  };

  // Quick generator for a single custom item
  const randomizeCustomEditor = () => {
    const c1 = generateRandomAestheticColor();
    const c2 = generateRandomAestheticColor();
    setCustomStart(c1);
    setCustomEnd(c2);
    setCustomAngle([45, 90, 135, 180, 270][Math.floor(Math.random() * 5)]);
    triggerToast('Randomized custom values! 🎲');
  };

  // Convert custom gradient details to Tailwind string
  const customGradientTailwind = useMemo(() => {
    return `bg-gradient-to-r from-[${customStart}] to-[${customEnd}]`;
  }, [customStart, customEnd]);

  // Convert angle state to standard CSS linear-gradient
  const customGradientCSS = useMemo(() => {
    return `linear-gradient(${customAngle}deg, ${customStart}, ${customEnd})`;
  }, [customAngle, customStart, customEnd]);

  return (
    <div className="min-h-screen bg-[#020617] text-slate-100 selection:bg-indigo-500 selection:text-white flex flex-col font-sans relative overflow-x-hidden transition-all">
      
      {/* Mesh Gradient Background Elements */}
      <div className="absolute top-[-10%] left-[-10%] w-[45%] h-[45%] bg-indigo-600/15 rounded-full blur-[120px] pointer-events-none z-0"></div>
      <div className="absolute bottom-[-5%] right-[-5%] w-[40%] h-[40%] bg-fuchsia-600/15 rounded-full blur-[120px] pointer-events-none z-0"></div>
      <div className="absolute top-[30%] right-[10%] w-[30%] h-[30%] bg-cyan-500/10 rounded-full blur-[100px] pointer-events-none z-0"></div>

      {/* Top Banner Message */}
      <div className="relative z-10 bg-zinc-950/80 backdrop-blur-md text-white py-2 px-4 text-xs font-mono text-center flex items-center justify-center gap-2 border-b border-white/5">
        <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
        <span>Vector Colours design release - premium aesthetic presets created on the fly</span>
        <span className="hidden md:inline text-zinc-400">| Press any element to instantly copy the code</span>
      </div>

      {/* Header Area */}
      <header id="app-header" className="relative z-40 sticky top-0 bg-white/5 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex flex-col md:flex-row items-center justify-between gap-4">
          
          {/* Logo Brand Title */}
          <div className="flex items-center gap-3">
            <div className="p-2 bg-gradient-to-tr from-indigo-500 via-indigo-600 to-purple-600 text-white rounded-xl shadow-lg shadow-indigo-500/10">
              <Palette className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight text-white uppercase font-sans">VECTOR COLOURS</h1>
              <p className="text-xs text-slate-400 font-mono">Atmospheric Harmony Engine</p>
            </div>
          </div>

          {/* Primary View Tab Controls */}
          <div className="flex items-center bg-black/30 p-1 rounded-xl border border-white/5 w-full md:w-auto">
            <button
              id="tab-grad"
              onClick={() => handleTabSwitch('gradients')}
              className={`flex-1 md:flex-none flex items-center justify-center gap-2 px-5 py-2 rounded-lg text-sm font-semibold transition ${
                currentTab === 'gradients'
                  ? 'bg-white/10 text-white shadow-sm font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Layers className="w-4 h-4" />
              Gradients
            </button>
            <button
              id="tab-combo"
              onClick={() => handleTabSwitch('combinations')}
              className={`flex-1 md:flex-none flex items-center justify-center gap-2 px-5 py-2 rounded-lg text-sm font-semibold transition ${
                currentTab === 'combinations'
                  ? 'bg-white/10 text-white shadow-sm font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Palette className="w-4 h-4" />
              Combinations
            </button>
            <button
              id="tab-sand"
              onClick={() => handleTabSwitch('sandbox')}
              className={`flex-1 md:flex-none flex items-center justify-center gap-2 px-5 py-2 rounded-lg text-sm font-semibold transition ${
                currentTab === 'sandbox'
                  ? 'bg-white/10 text-white shadow-sm font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Eye className="w-4 h-4" />
              Live Preview
            </button>
            <button
              id="tab-favs"
              onClick={() => handleTabSwitch('favorites')}
              className={`flex-1 md:flex-none flex items-center justify-center gap-2 px-5 py-2 rounded-lg text-sm font-semibold transition relative ${
                currentTab === 'favorites'
                  ? 'bg-white/10 text-white shadow-sm font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Star className="w-4 h-4 text-amber-500 fill-amber-400" />
              <span>Saved</span>
              {(favGradients.length + favPalettes.length) > 0 && (
                <span className="absolute -top-1 right-0.5 w-4 h-4 bg-amber-500 text-white rounded-full text-[10px] flex items-center justify-center font-bold">
                  {favGradients.length + favPalettes.length}
                </span>
              )}
            </button>
          </div>

          {/* Sizing Toggles */}
          <div className="hidden lg:flex items-center gap-1.5 bg-black/20 p-1 rounded-lg border border-white/5">
            <button
              onClick={() => setGridSize('compact')}
              className={`p-1.5 rounded transition ${gridSize === 'compact' ? 'bg-white/10 text-white shadow-sm' : 'text-slate-500 hover:text-slate-300'}`}
              title="Compact presentation grid"
            >
              <Grid2X2 className="w-4 h-4" />
            </button>
            <button
              onClick={() => setGridSize('normal')}
              className={`p-1.5 rounded transition ${gridSize === 'normal' ? 'bg-white/10 text-white shadow-sm' : 'text-slate-500 hover:text-slate-300'}`}
              title="Perfect default grid size"
            >
              <Grid3X3 className="w-4 h-4" />
            </button>
            <button
              onClick={() => setGridSize('large')}
              className={`p-1.5 rounded transition ${gridSize === 'large' ? 'bg-white/10 text-white shadow-sm' : 'text-slate-500 hover:text-slate-300'}`}
              title="Comfortable card inspection layout"
            >
              <List className="w-4 h-4" />
            </button>
          </div>

        </div>
      </header>

      {/* Hero Header Area */}
      {currentTab !== 'sandbox' && (
        <section className="relative z-10 border-b border-white/5 py-12 px-6">
          <div className="max-w-4xl mx-auto text-center">
            
            {/* Dynamic subtitle depending on location */}
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="inline-flex items-center gap-2 px-3 py-1 bg-white/5 border border-white/10 text-indigo-300 rounded-full text-xs font-semibold mb-4"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Aesthetic Color Palette Generator</span>
            </motion.div>

            <h2 className="text-3xl sm:text-4xl md:text-5xl font-light text-slate-100 tracking-tight leading-none mb-3">
              Explore <span className="font-semibold text-white">Atmospheric Blends</span>
            </h2>
            <p className="text-slate-400 max-w-2xl mx-auto text-sm sm:text-base leading-relaxed mb-6">
              A carefully crafted library of beautiful color harmonies and multi-stop gradients designed for modern frosted-glass product interfaces. Select tags, copy hex values, and debug them in our interactive sandbox preview.
            </p>

            {/* Quick Stats Banner */}
            <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-xs font-mono text-slate-500">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                <span>Active Database: 5,000+ Combinations</span>
              </span>
              <span className="hidden sm:inline text-slate-700">•</span>
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-indigo-500"></span>
                <span>Contrast Ratio Checked (W3C Standard)</span>
              </span>
              <span className="hidden sm:inline text-slate-705">•</span>
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-pink-500"></span>
                <span>Export formats: Hex / CSS / Tailwind</span>
              </span>
            </div>

          </div>
        </section>
      )}

      {/* Primary Toolbar for Filtering and Search */}
      {currentTab !== 'sandbox' && (
        <div className="relative z-30 bg-white/5 backdrop-blur-md border-b border-white/10 p-4 sticky top-[73px] shadow-sm">
          <div className="max-w-7xl mx-auto flex flex-col md:flex-row gap-4 items-center justify-between">
            
            {/* Horizontal Filter Tags Slider */}
            <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto pb-1 md:pb-0 scrollbar-none">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500 mr-2 shrink-0">Tags:</span>
              {tags.map((tag) => (
                <button
                  key={tag}
                  onClick={() => setTagFilter(tag)}
                  className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                    tagFilter === tag
                      ? 'bg-white text-black opacity-100 shadow-sm font-bold'
                      : 'bg-white/5 text-slate-400 hover:bg-white/10 hover:text-white'
                  }`}
                >
                  {tag === 'All' ? 'All Colors' : tag}
                </button>
              ))}
            </div>

            {/* Search Input Filter Container */}
            <div className="relative w-full md:w-72">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by name, hex, tag..."
                className="w-full bg-white/5 hover:bg-white/10 focus:bg-black/30 text-white text-sm pl-10 pr-4 py-2 rounded-xl border border-white/10 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition duration-150"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-500 hover:text-slate-300 py-1 px-1.5"
                >
                  Clear
                </button>
              )}
            </div>

          </div>
        </div>
      )}

      {/* Main Grid Content Area */}
      <main className="relative z-10 flex-1 max-w-7xl mx-auto px-4 sm:px-6 py-8 w-full">
        
        {/* TAB 1: GRADIENTS GRID */}
        {currentTab === 'gradients' && (
          <div className="space-y-10">
            {filteredGradients.length === 0 ? (
              <div className="text-center py-20 bg-white/5 backdrop-blur-lg rounded-2xl border border-dashed border-white/10 max-w-lg mx-auto p-8">
                <Layers className="w-12 h-12 text-slate-500 mx-auto mb-4" />
                <p className="text-white font-bold text-lg mb-1">No matching gradients found</p>
                <p className="text-slate-400 text-sm mb-6">Try clearing your search keyword or selected tag filter rules.</p>
                <button
                  onClick={() => { setTagFilter('All'); setSearchQuery(''); }}
                  className="inline-flex items-center gap-2 px-4 py-2 bg-white text-black hover:bg-slate-200 rounded-lg text-sm font-semibold transition"
                >
                  Reset Current Filter
                </button>
              </div>
            ) : (
              <div>
                <div className={`grid ${gridClasses}`}>
                  {displayedGradients.map((item) => {
                    const isFaved = favGradients.some(g => g.id === item.id);
                    const gradientCSSRule = `linear-gradient(${item.angle}deg, ${item.colors[0]}, ${item.colors[1]})`;
                    
                    return (
                      <motion.div
                        layout
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="group relative bg-white/5 backdrop-blur-lg rounded-2xl border border-white/10 overflow-hidden shadow-sm hover:shadow-xl hover:border-white/20 transition duration-300 flex flex-col"
                        key={item.id}
                      >
                        {/* Gradient visual strip */}
                        <div
                          className="h-44 w-full relative group-hover:h-48 transition-all duration-300"
                          style={{ background: gradientCSSRule }}
                        >
                          {/* Top badge indicators */}
                          <div className="absolute top-3 left-3 flex gap-1.5">
                            {item.tags.map(t => (
                              <span key={t} className="px-2 py-0.5 bg-black/40 text-white backdrop-blur-md rounded text-[10px] uppercase font-mono tracking-wider">
                                {t}
                              </span>
                            ))}
                          </div>

                          {/* Top Right Bookmark Favorites Control */}
                          <button
                            onClick={(e) => toggleFavGradient(item, e)}
                            className="absolute top-3 right-3 p-2 bg-black/40 hover:bg-black/60 text-white backdrop-blur-md rounded-full shadow-lg transition"
                            title={isFaved ? 'Remove from saved' : 'Save to favorites'}
                          >
                            <Star className={`w-4 h-4 ${isFaved ? 'fill-amber-400 text-amber-400' : 'text-white'}`} />
                          </button>

                          {/* Hover Sandbox Playground Preview Button */}
                          <div className="absolute inset-0 bg-black/10 opacity-0 group-hover:opacity-100 flex items-center justify-center transition duration-200">
                            <button
                              onClick={() => {
                                setSandboxGradient(item);
                                setCustomStart(item.colors[0]);
                                setCustomEnd(item.colors[1]);
                                setCustomAngle(item.angle);
                                setCurrentTab('sandbox');
                                triggerToast('Loaded gradient to designer sandbox!');
                              }}
                              className="px-4 py-2 bg-white text-zinc-950 font-semibold rounded-lg shadow-xl text-xs flex items-center gap-1.5 transform translate-y-2 group-hover:translate-y-0 transition duration-200 hover:bg-slate-100"
                            >
                              <Eye className="w-3.5 h-3.5 text-indigo-600" />
                              Open in Sandbox
                            </button>
                          </div>
                        </div>

                        {/* Title and control specs */}
                        <div className="p-4 bg-black/20 flex-1 flex flex-col justify-between">
                          <div className="flex justify-between items-start mb-3">
                            <div>
                              <h3 className="font-bold text-slate-100 group-hover:text-indigo-400 transition text-sm sm:text-base">
                                {item.name}
                              </h3>
                              <p className="text-xs font-mono text-slate-400 mt-0.5 uppercase tracking-wide">
                                {item.colors[0]} → {item.colors[1]}
                              </p>
                            </div>
                            <span className="text-xs bg-white/10 text-slate-350 font-mono py-1 px-2 rounded-md">
                              {item.angle}°
                            </span>
                          </div>

                          {/* Quick copy buttons block */}
                          <div className="grid grid-cols-2 gap-2 mt-4 pt-4 border-t border-white/5">
                            <button
                              onClick={() => copyText(gradientCSSRule, 'CSS Linear Gradient')}
                              className="text-xs bg-white/5 hover:bg-white/15 text-slate-200 py-2 px-2.5 rounded-lg font-semibold flex items-center justify-center gap-1.5 transition border border-white/10"
                            >
                              <Copy className="w-3.5 h-3.5" />
                              Copy CSS
                            </button>
                            <button
                              onClick={() => copyText(`from-[${item.colors[0]}] to-[${item.colors[1]}]`, 'Tailwind snippet')}
                              className="text-xs bg-white/5 hover:bg-white/15 text-slate-200 py-2 px-2.5 rounded-lg font-semibold flex items-center justify-center gap-1.5 transition border border-white/10"
                            >
                              <Palette className="w-3.5 h-3.5" />
                              Tailwind
                            </button>
                          </div>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>

                {/* Main Pagination or Endless Scroll trigger */}
                <div className="flex flex-col items-center justify-center mt-12 py-10 border-t border-white/10">
                  <button
                    onClick={loadMore}
                    className="group flex items-center gap-3 bg-white hover:bg-slate-100 text-black px-10 py-4 rounded-xl font-semibold shadow-lg shadow-white/5 hover:shadow-indigo-500/10 transition-all transform hover:-translate-y-0.5"
                  >
                    <RefreshCw className="w-4 h-4 text-indigo-600 group-hover:rotate-180 transition-transform duration-500" />
                    Generate Infinite Gradients
                  </button>
                  <p className="text-xs text-slate-400 mt-3 font-mono">
                    Programmatically triggers a responsive sequence based on chosen style aesthetics
                  </p>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: COMBINATIONS (PALETTES) GRID */}
        {currentTab === 'combinations' && (
          <div className="space-y-10">
            {filteredPalettes.length === 0 ? (
              <div className="text-center py-20 bg-white/5 backdrop-blur-lg rounded-2xl border border-dashed border-white/10 max-w-lg mx-auto p-8">
                <Palette className="w-12 h-12 text-slate-500 mx-auto mb-4" />
                <p className="text-white font-bold text-lg mb-1">No matching palettes found</p>
                <p className="text-slate-400 text-sm mb-6">Try resetting search keywords or look for another tag preset.</p>
                <button
                  onClick={() => { setTagFilter('All'); setSearchQuery(''); }}
                  className="inline-flex items-center gap-2 px-4 py-2 bg-white text-black hover:bg-slate-200 rounded-lg text-sm font-semibold transition"
                >
                  Reset Current Filter
                </button>
              </div>
            ) : (
              <div>
                <div className={`grid ${gridClasses}`}>
                  {displayedPalettes.map((item) => {
                    const isFaved = favPalettes.some(p => p.id === item.id);
                    
                    return (
                      <motion.div
                        layout
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="group relative bg-white/5 backdrop-blur-lg rounded-2xl border border-white/10 overflow-hidden shadow-sm hover:shadow-xl hover:border-white/20 transition duration-300 flex flex-col"
                        key={item.id}
                      >
                        {/* 4 Multi-color stripes stack */}
                        <div className="h-44 w-full flex relative group-hover:h-48 transition-all duration-300">
                          {item.colors.map((hex, index) => (
                            <div
                              key={`${hex}-${index}`}
                              onClick={() => {
                                copyText(hex, `Hex code ${hex}`);
                                generateRelatedColors(hex);
                              }}
                              className="h-full flex-1 relative cursor-pointer hover:flex-[1.8] hover:shadow-2xl transition-all duration-350 p-2 flex flex-col justify-end items-center group/stripe"
                              style={{ backgroundColor: hex }}
                              title={`Click to copy Hex: ${hex}`}
                            >
                              {/* Overlay tiny copy text */}
                              <span className="opacity-0 group-hover/stripe:opacity-100 bg-black/75 text-white backdrop-blur-md px-1.5 py-0.5 rounded text-[9px] font-mono transition duration-150 mb-1">
                                Copy
                              </span>
                              
                              {/* Hex indicators visible inside color stripe */}
                              <span className="bg-white text-black border border-white/20 px-1 rounded text-[10px] font-mono tracking-tighter opacity-0 group-hover:opacity-100 transition duration-200">
                                {hex.toUpperCase()}
                              </span>
                            </div>
                          ))}

                          {/* Saved / Favoriting Button on top */}
                          <div className="absolute top-3 left-3 flex gap-1.5">
                            {item.tags.map(t => (
                              <span key={t} className="px-2 py-0.5 bg-black/40 text-white backdrop-blur-md rounded text-[10px] uppercase font-mono tracking-wider">
                                {t}
                              </span>
                            ))}
                          </div>

                          <button
                            onClick={(e) => toggleFavPalette(item, e)}
                            className="absolute top-3 right-3 p-2 bg-black/40 hover:bg-black/60 text-white backdrop-blur-md rounded-full shadow-lg transition"
                            title={isFaved ? 'Remove from saved' : 'Save palette'}
                          >
                            <Star className={`w-4 h-4 ${isFaved ? 'fill-amber-400 text-amber-400' : 'text-white'}`} />
                          </button>
                        </div>

                        {/* Title and stats layout */}
                        <div className="p-4 bg-black/20 flex-1 flex flex-col justify-between">
                          <div className="flex justify-between items-center mb-3">
                            <h3 className="font-bold text-slate-100 text-sm sm:text-base group-hover:text-indigo-400 transition">
                              {item.name}
                            </h3>
                            <button
                              onClick={() => applyPaletteToSandbox(item)}
                              className="p-1 px-2.5 bg-white/10 hover:bg-white hover:text-black rounded-lg text-[11px] font-semibold text-slate-200 transition flex items-center gap-1"
                              title="Render in UI preview container"
                            >
                              <Eye className="w-3.5 h-3.5" />
                              Preview
                            </button>
                          </div>

                          {/* Quick Palette Utility copies */}
                          <div className="grid grid-cols-2 gap-2 pt-3 border-t border-white/5">
                            <button
                              onClick={() => copyText(JSON.stringify(item.colors), 'JSON color array')}
                              className="text-xs bg-white/5 hover:bg-white/15 py-2 rounded-lg font-semibold text-slate-350 flex items-center justify-center gap-1 transition border border-white/10"
                            >
                              <Copy className="w-3.5 h-3.5" />
                              Copy Array
                            </button>
                            <button
                              onClick={() => copyText(`[${item.colors.join(', ')}]`, 'CSS variables list')}
                              className="text-xs bg-white/5 hover:bg-white/15 py-2 rounded-lg font-semibold text-slate-350 flex items-center justify-center gap-1 transition border border-white/10"
                            >
                              <SlidersHorizontal className="w-3.5 h-3.5" />
                              Full Palette
                            </button>
                          </div>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>

                {/* Pagination load more element */}
                <div className="flex flex-col items-center justify-center mt-12 py-10 border-t border-white/10">
                  <button
                    onClick={loadMore}
                    className="group flex items-center gap-3 bg-white hover:bg-slate-101 text-black px-10 py-4 rounded-xl font-semibold shadow-lg transition-all transform hover:-translate-y-0.5"
                  >
                    <RefreshCw className="w-4 h-4 text-indigo-600 group-hover:rotate-180 transition-transform duration-500" />
                    Generate Infinite Combinations
                  </button>
                  <p className="text-xs text-slate-400 mt-3 font-mono">
                    Combines modern web accessibility contrast metrics automatically
                  </p>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 3: THE INTERACTIVE DESIGNER SANDBOX */}
        {currentTab === 'sandbox' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start relative z-10">
            
            {/* LEFT COLUMN: EDITOR AND CONTROLS (5 Cols) */}
            <div className="lg:col-span-5 bg-white/5 backdrop-blur-xl p-6 rounded-2xl border border-white/10 space-y-6">
              
              {/* Box Header */}
              <div className="flex justify-between items-center pb-4 border-b border-white/10">
                <div className="flex items-center gap-2">
                  <Sliders className="w-5 h-5 text-indigo-400" />
                  <h3 className="font-bold text-white text-base">Custom Gradient Creator</h3>
                </div>
                <button
                  onClick={randomizeCustomEditor}
                  className="p-1.5 hover:bg-white/10 text-slate-400 hover:text-white rounded-lg transition"
                  title="Randomize editor inputs"
                >
                  <RefreshCw className="w-4 h-4 animate-spin-slow" />
                </button>
              </div>

              {/* Start Color */}
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <label className="text-xs font-bold uppercase tracking-wider text-slate-400">From / Starting Hex</label>
                  <span className="text-xs font-mono text-indigo-300">{customStart}</span>
                </div>
                <div className="flex gap-2">
                  <div className="relative w-12 h-10 rounded-lg overflow-hidden border border-white/10 grow-0 shrink-0">
                    <input
                      type="color"
                      value={customStart}
                      onChange={(e) => setCustomStart(e.target.value)}
                      className="absolute inset-[-4px] w-[56px] h-[48px] cursor-pointer"
                    />
                  </div>
                  <input
                    type="text"
                    value={customStart}
                    onChange={(e) => setCustomStart(e.target.value)}
                    placeholder="#3b82f6"
                    maxLength={7}
                    className="flex-1 bg-black/30 border border-white/10 text-white rounded-lg text-sm px-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 uppercase font-mono"
                  />
                </div>
              </div>

              {/* End Color */}
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <label className="text-xs font-bold uppercase tracking-wider text-slate-400">To / Ending Hex</label>
                  <span className="text-xs font-mono text-indigo-300">{customEnd}</span>
                </div>
                <div className="flex gap-2">
                  <div className="relative w-12 h-10 rounded-lg overflow-hidden border border-white/10 grow-0 shrink-0">
                    <input
                      type="color"
                      value={customEnd}
                      onChange={(e) => setCustomEnd(e.target.value)}
                      className="absolute inset-[-4px] w-[56px] h-[48px] cursor-pointer"
                    />
                  </div>
                  <input
                    type="text"
                    value={customEnd}
                    onChange={(e) => setCustomEnd(e.target.value)}
                    placeholder="#ec4899"
                    maxLength={7}
                    className="flex-1 bg-black/30 border border-white/10 text-white rounded-lg text-sm px-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 uppercase font-mono"
                  />
                </div>
              </div>

              {/* Gradient Angle Slider */}
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <label className="text-xs font-bold uppercase tracking-wider text-slate-400">Orientation Angle</label>
                  <span className="text-xs font-mono bg-white/10 text-indigo-200 py-0.5 px-2 rounded font-bold">
                    {customAngle}°
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="360"
                  step="5"
                  value={customAngle}
                  onChange={(e) => setCustomAngle(Number(e.target.value))}
                  className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer accent-indigo-500 focus:outline-none"
                />
                <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                  <span>0° (Vertical Up)</span>
                  <span>180° (Vertical Down)</span>
                  <span>360°</span>
                </div>
              </div>

              {/* Copy Code Snippets Options Box */}
              <div className="bg-black/30 p-4 rounded-xl border border-white/5 space-y-4">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wide flex items-center gap-1">
                  <Info className="w-3.5 h-3.5 text-slate-500" />
                  Generated Code Outputs
                </p>

                {/* CSS snippet copy */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                    <span>CSS rule format</span>
                    <button
                      onClick={() => copyText(`background: ${customGradientCSS};`, 'raw CSS Code')}
                      className="hover:text-indigo-400 flex items-center gap-0.5 transition"
                    >
                      <Copy className="w-2.5 h-2.5" /> Copy Code
                    </button>
                  </div>
                  <pre className="bg-black/40 text-slate-300 font-mono text-[11px] p-2 rounded border border-white/5 break-all overflow-x-auto whitespace-pre-wrap select-all">
                    {`background: ${customGradientCSS};`}
                  </pre>
                </div>

                {/* Tailwind snippet copy */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                    <span>Tailwind class matching</span>
                    <button
                      onClick={() => copyText(`bg-gradient-to-r from-[${customStart}] to-[${customEnd}]`, 'Tailwind Arbitrary utility snippet')}
                      className="hover:text-indigo-400 flex items-center gap-0.5 transition"
                    >
                      <Copy className="w-2.5 h-2.5" /> Copy Code
                    </button>
                  </div>
                  <pre className="bg-black/40 text-slate-300 font-mono text-[11px] p-2 rounded border border-white/5 break-all overflow-x-auto whitespace-pre-wrap select-all">
                    {`bg-gradient-to-r from-[${customStart}] to-[${customEnd}]`}
                  </pre>
                </div>
              </div>

              {/* Apply Preset Palette helper inside editor */}
              <div className="space-y-2">
                <p className="text-xs font-bold uppercase tracking-wider text-slate-400">Quick Inject Curated Gradient Presets</p>
                <div className="grid grid-cols-4 gap-2">
                  {PRESET_GRADIENTS.slice(0, 8).map((item) => (
                    <button
                      key={item.id}
                      onClick={() => {
                        setCustomStart(item.colors[0]);
                        setCustomEnd(item.colors[1]);
                        setCustomAngle(item.angle);
                      }}
                      className="h-10 rounded-lg cursor-pointer hover:scale-110 active:scale-95 transition-all border border-white/10"
                      style={{ background: `linear-gradient(${item.angle}deg, ${item.colors[0]}, ${item.colors[1]})` }}
                      title={`Load colors: ${item.name}`}
                    />
                  ))}
                </div>
              </div>

            </div>

            {/* RIGHT COLUMN: LIVE INTERACTIVE PREVIEWS (7 Cols) */}
            <div className="lg:col-span-7 space-y-8">
              
              {/* Segment Header */}
              <div className="bg-white/5 backdrop-blur-xl p-4 rounded-xl border border-white/10 flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-white text-sm">Interactive Live Playground</h4>
                  <p className="text-xs text-slate-400 font-mono text-[11px]">Your selections are automatically injected into the mockup sandbox elements below</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-indigo-500 animate-pulse"></span>
                  <span className="text-xs font-bold text-indigo-300">Preview Engine Active</span>
                </div>
              </div>

              {/* PREVIEW CONTAINER 1: THE ACCELERATED SAAS LANDING HERO BANNER */}
              <div className="bg-white/5 backdrop-blur-xl rounded-2xl border border-white/10 overflow-hidden">
                <div className="bg-black/40 text-slate-300 p-3 px-4 text-[11px] font-mono border-b border-white/5 flex items-center justify-between">
                  <span>🚀 Component mockup: SaaS Landing Hero Block</span>
                  <div className="flex gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-red-500/60"></span>
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-500/60"></span>
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/60"></span>
                  </div>
                </div>

                <div className="p-8 sm:p-12 text-center bg-[#020617]/90 relative overflow-hidden flex flex-col justify-center items-center min-h-[300px]">
                  
                  {/* Subtle vector grid bg overlay */}
                  <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff05_1px,transparent_1px),linear-gradient(to_bottom,#ffffff05_1px,transparent_1px)] bg-[size:24px_24px]" />
                  
                  {/* Dynamic background lighting aura */}
                  <div
                    className="absolute -top-16 opacity-30 w-72 h-72 rounded-full blur-[100px] transition-all duration-300"
                    style={{ background: customGradientCSS }}
                  />

                  <div className="relative z-10 space-y-6 max-w-xl">
                    <p className="text-xs font-bold font-mono uppercase tracking-widest text-indigo-400 flex items-center justify-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5" />
                      Digital Transformation Engine
                    </p>
                    
                    {/* Visual Headline utilizing custom CSS styling */}
                    <h1
                      className="text-2xl sm:text-4xl font-light tracking-tight text-transparent bg-clip-text"
                      style={{
                        backgroundImage: customGradientCSS,
                        WebkitBackgroundClip: 'text',
                        WebkitTextFillColor: 'transparent',
                      }}
                    >
                      Accelerate Your Next <strong className="font-bold">Digital Interface</strong>
                    </h1>

                    <p className="text-slate-400 text-xs sm:text-sm leading-relaxed max-w-md mx-auto">
                      A visual representation of current colors in action. See how custom gradient angles impact typography and interface dynamics.
                    </p>

                    <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                      <button
                        className="px-5 py-2.5 rounded-lg text-xs font-bold text-white shadow-xl transition hover:opacity-90 active:scale-95"
                        style={{ background: customGradientCSS }}
                      >
                        Launch Visual Console
                      </button>
                      <button className="px-5 py-2.5 rounded-lg text-xs font-semibold text-slate-400 bg-white/5 border border-white/10 hover:text-white hover:bg-white/10 transition">
                        Documentation
                      </button>
                    </div>

                  </div>
                </div>
              </div>

              {/* PREVIEW CONTAINER 2: DYNAMIC CARD ELEMENTS */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Visual Pricing Card */}
                <div className="bg-white/5 backdrop-blur-xl rounded-2xl border border-white/10 overflow-hidden flex flex-col justify-between">
                  <div className="p-1" style={{ background: customGradientCSS }} />
                  <div className="p-6 space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Premium Pro</span>
                      <span className="px-2.5 py-0.5 bg-indigo-500/20 text-indigo-300 text-[10px] rounded-full font-bold">Best Value</span>
                    </div>

                    <div className="flex items-baseline gap-1">
                      <span className="text-3xl font-extrabold text-white">$49</span>
                      <span className="text-xs text-slate-400 font-mono">/ designer seat</span>
                    </div>

                    <ul className="space-y-2 text-xs text-slate-300">
                      <li className="flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                        <span>Unlimited CSS Vector exports</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                        <span>SaaS Developer visual presets</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                        <span>Tailwind config generation tool</span>
                      </li>
                    </ul>

                    <button
                      className="w-full text-white py-2.5 rounded-xl text-xs font-bold shadow-lg transition hover:shadow-xl active:scale-95"
                      style={{ background: customGradientCSS }}
                    >
                      Subscribe Pro Seat
                    </button>
                  </div>
                </div>

                {/* Dashboard Widget Interface */}
                <div className="bg-white/5 backdrop-blur-xl rounded-2xl border border-white/10 p-6 space-y-4">
                  <div className="flex justify-between items-center">
                    <h5 className="font-bold text-white text-xs sm:text-sm">Revenue Conversions</h5>
                    <span className="text-xs text-emerald-400 font-bold">+18.4%</span>
                  </div>

                  {/* Interactive Chart indicator colored dynamically */}
                  <div className="h-28 bg-black/40 rounded-xl relative overflow-hidden flex items-end">
                    
                    {/* Visual graph line representation */}
                    <div className="absolute inset-0 p-4 opacity-5 bg-[linear-gradient(to_right,#ffffff10_1px,transparent_1px),linear-gradient(to_bottom,#ffffff10_1px,transparent_1px)] bg-[size:16px_16px]" />
                    
                    {/* Filled bar graph steps colored via gradient */}
                    <div className="w-full h-full flex items-end justify-between px-4 pb-2 relative z-10 gap-2">
                      <div className="w-4 h-[30%] rounded-md hover:scale-105 transition" style={{ background: customGradientCSS }}></div>
                      <div className="w-4 h-[44%] rounded-md hover:scale-105 transition" style={{ background: customGradientCSS }}></div>
                      <div className="w-4 h-[65%] rounded-md hover:scale-105 transition" style={{ background: customGradientCSS }}></div>
                      <div className="w-4 h-[55%] rounded-md hover:scale-105 transition" style={{ background: customGradientCSS }}></div>
                      <div className="w-4 h-[90%] rounded-md hover:scale-105 transition" style={{ background: customGradientCSS }}></div>
                    </div>
                  </div>

                  <div className="flex justify-between text-[11px] font-mono text-slate-500">
                    <span>Mon</span>
                    <span>Wed</span>
                    <span>Fri</span>
                    <span>Today</span>
                  </div>
                </div>

              </div>

            </div>

          </div>
        )}

        {/* TAB 4: MY FAVORITES SECTION */}
        {currentTab === 'favorites' && (
          <div className="space-y-10 relative z-10">
            
            {/* Header statistics bar */}
            <div className="bg-white/5 backdrop-blur-xl p-6 rounded-2xl border border-white/10 flex flex-col md:flex-row gap-4 items-center justify-between shadow-sm">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-white/5 rounded-xl text-amber-400 border border-white/5">
                  <FolderHeart className="w-6 h-6 text-amber-500 fill-amber-400/20" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-lg">Your Saved Masterpieces</h3>
                  <p className="text-xs text-slate-400">Click individual parameters to access code formats. Local persistence active.</p>
                </div>
              </div>

              {(favGradients.length + favPalettes.length) > 0 && (
                <button
                  onClick={() => {
                    setFavGradients([]);
                    setFavPalettes([]);
                    triggerToast('Cleared all favorites successfully.');
                  }}
                  className="flex items-center gap-1.5 px-4 py-2 bg-red-500/10 hover:bg-red-500/20 text-red-300 hover:text-red-200 rounded-lg text-xs font-semibold border border-red-500/20 transition"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Clear All Favorites
                </button>
              )}
            </div>

            {/* Sub-section: Favorite Gradients */}
            <div className="space-y-6">
              <h4 className="text-sm font-bold uppercase tracking-wider text-slate-400 flex items-center gap-2">
                <span className="w-1.5 h-3 bg-indigo-500 rounded-full"></span>
                Saved Gradients ({favGradients.length})
              </h4>

              {favGradients.length === 0 ? (
                <div className="text-center py-12 bg-white/5 backdrop-blur-md rounded-2xl border border-dashed border-white/10 p-6">
                  <Layers className="w-8 h-8 text-slate-500 mx-auto mb-2" />
                  <p className="text-white font-semibold text-sm">No gradients saved yet</p>
                  <p className="text-slate-400 text-xs max-w-xs mx-auto mt-1 mb-4">Go to the main Gradients tab and star colors you like!</p>
                  <button
                    onClick={() => handleTabSwitch('gradients')}
                    className="text-xs bg-white text-black hover:bg-slate-200 font-semibold py-1.5 px-3 rounded-lg transition"
                  >
                    Browse Gradients
                  </button>
                </div>
              ) : (
                <div className={`grid ${gridClasses}`}>
                  {favGradients.map((item) => {
                    const gradientCSSRule = `linear-gradient(${item.angle}deg, ${item.colors[0]}, ${item.colors[1]})`;
                    
                    return (
                      <div
                        className="group relative bg-white/5 backdrop-blur-lg rounded-xl border border-white/10 overflow-hidden shadow-sm hover:shadow-md transition"
                        key={`fav-${item.id}`}
                      >
                        <div className="h-32 w-full relative" style={{ background: gradientCSSRule }}>
                          
                          {/* Remove favoriting control */}
                          <button
                            onClick={(e) => toggleFavGradient(item, e)}
                            className="absolute top-2 right-2 p-1.5 bg-black/40 hover:bg-black/60 text-white rounded-full shadow-lg transition"
                          >
                            <Trash2 className="w-3.5 h-3.5 text-red-300" />
                          </button>
                        </div>
                        <div className="p-3 bg-black/20">
                          <div className="flex justify-between items-center mb-2">
                            <span className="font-bold text-white text-xs sm:text-sm">{item.name}</span>
                            <span className="text-[10px] font-mono bg-white/10 text-slate-300 py-0.5 px-1.5 rounded">{item.angle}°</span>
                          </div>
                          
                          <div className="grid grid-cols-2 gap-1.5 pt-2 border-t border-white/5">
                            <button
                              onClick={() => copyText(gradientCSSRule, 'CSS Gradient code')}
                              className="text-[11px] bg-white/5 hover:bg-white/15 py-1.5 rounded font-semibold text-slate-300 transition"
                            >
                              Copy CSS
                            </button>
                            <button
                              onClick={() => loadIntoEditor(item.colors, item.angle)}
                              className="text-[11px] bg-white/5 hover:bg-white/15 py-1.5 rounded font-semibold text-slate-300 transition"
                            >
                              Sandbox
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Sub-section: Favorite Color Combinations */}
            <div className="space-y-6 pt-4">
              <h4 className="text-sm font-bold uppercase tracking-wider text-slate-400 flex items-center gap-2">
                <span className="w-1.5 h-3 bg-pink-500 rounded-full"></span>
                Saved Combinations ({favPalettes.length})
              </h4>

              {favPalettes.length === 0 ? (
                <div className="text-center py-12 bg-white/5 backdrop-blur-md rounded-2xl border border-dashed border-white/10 p-6">
                  <Palette className="w-8 h-8 text-slate-500 mx-auto mb-2" />
                  <p className="text-white font-semibold text-sm">No combinations saved yet</p>
                  <p className="text-slate-400 text-xs max-w-xs mx-auto mt-1 mb-4">Click the star badge on palette cards to persist them here!</p>
                  <button
                    onClick={() => handleTabSwitch('combinations')}
                    className="text-xs bg-white text-black hover:bg-slate-200 font-semibold py-1.5 px-3 rounded-lg transition"
                  >
                    Explore Palettes
                  </button>
                </div>
              ) : (
                <div className={`grid ${gridClasses}`}>
                  {favPalettes.map((item) => (
                    <div
                      className="group relative bg-white/5 backdrop-blur-lg rounded-xl border border-white/10 overflow-hidden shadow-sm hover:shadow-md transition"
                      key={`fav-${item.id}`}
                    >
                      <div className="h-32 w-full flex relative">
                        {item.colors.map((hex, index) => (
                          <div
                            key={`${hex}-${index}`}
                            onClick={() => {
                              copyText(hex, `Hex code ${hex}`);
                              generateRelatedColors(hex);
                            }}
                            className="h-full flex-1 hover:flex-[1.4] transition-all cursor-pointer"
                            style={{ backgroundColor: hex }}
                            title={`Copy hex: ${hex}`}
                          />
                        ))}
                        
                        {/* Remove control */}
                        <button
                          onClick={(e) => toggleFavPalette(item, e)}
                          className="absolute top-2 right-2 p-1.5 bg-black/40 hover:bg-black/60 text-white rounded-full shadow-lg transition"
                        >
                          <Trash2 className="w-3.5 h-3.5 text-red-300" />
                        </button>
                      </div>
                      <div className="p-3 bg-black/20">
                        <div className="flex justify-between items-center mb-2">
                          <span className="font-bold text-white text-xs sm:text-sm">{item.name}</span>
                          <button
                            onClick={() => applyPaletteToSandbox(item)}
                            className="text-[10px] bg-white/10 text-white px-1.5 py-0.5 rounded font-bold hover:bg-white hover:text-black transition"
                          >
                            Preview
                          </button>
                        </div>
                        <div className="grid grid-cols-2 gap-1.5 pt-2 border-t border-white/5">
                          <button
                            onClick={() => copyText(JSON.stringify(item.colors), 'JSON Palette array')}
                            className="text-[11px] bg-white/5 hover:bg-white/15 py-1.5 rounded font-semibold text-slate-300 transition"
                          >
                            Copy Array
                          </button>
                          <button
                            onClick={() => copyText(`[${item.colors.join(', ')}]`, 'CSS custom properties list')}
                            className="text-[11px] bg-white/5 hover:bg-white/15 py-1.5 rounded font-semibold text-slate-300 transition"
                          >
                            Full Details
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

          </div>
        )}

      </main>

      {/* FOOTER SECTION */}
      <footer className="relative z-10 bg-black/50 backdrop-blur-xl border-t border-white/10 py-12 px-6 mt-16 text-center text-slate-400 text-xs font-mono">
        <div className="max-w-7xl mx-auto space-y-4">
          <div className="flex items-center justify-center gap-2 text-indigo-400">
            <Palette className="w-4 h-4" />
            <span className="font-bold text-sm tracking-wider text-white uppercase font-sans">VECTOR COLOURS Engine v2.4</span>
          </div>
          <p className="max-w-md mx-auto leading-relaxed text-slate-400 font-sans">
            Crafted for developers and designers who value pristine quality. Click any color stop to instantly populate clipboard buffers. All colors checked for maximum modern web accessibility contrast constraints.
          </p>
          <div className="flex items-center justify-center gap-x-4 gap-y-1 flex-wrap text-slate-500 pt-2 text-[10px]">
            <span>Client-side Cache: LocalStorage</span>
            <span>•</span>
            <span>W3C Level AA Compliant</span>
            <span>•</span>
            <span>Vite Server Active</span>
          </div>
        </div>
      </footer>

      {/* AI GENERATED COLOR HARMONY DRAWER / MODAL */}
      <AnimatePresence>
        {showAIPanel && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAIPanel(false)}
              className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm"
            />
            
            {/* Modal Body */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-lg bg-slate-900/95 border border-white/10 rounded-2xl shadow-2xl p-6 overflow-hidden z-10"
            >
              {/* Mesh background effect in card */}
              <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-indigo-500/10 rounded-full blur-[80px] pointer-events-none" />

              <div className="relative z-15 space-y-6">
                
                {/* Header */}
                <div className="flex items-center justify-between border-b border-white/5 pb-4">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-indigo-400 animate-pulse" />
                    <h3 className="font-bold text-white text-base">Gemini Color Architect</h3>
                  </div>
                  <button
                    onClick={() => setShowAIPanel(false)}
                    className="p-1.5 hover:bg-white/10 rounded-lg text-slate-400 hover:text-white transition"
                    title="Close Panel"
                  >
                    ✕
                  </button>
                </div>

                {/* Loading state */}
                {isGenerating && (
                  <div className="py-12 flex flex-col items-center justify-center space-y-4">
                    <div className="w-10 h-10 border-4 border-indigo-500/20 border-t-indigo-500 rounded-full animate-spin" />
                    <div className="text-center">
                      <p className="text-sm font-semibold text-white">Drafting related colors with Gemini...</p>
                      <p className="text-xs text-slate-400 mt-1 font-mono">Calibrating accessibility and harmony ratios</p>
                    </div>
                  </div>
                )}

                {/* Results state */}
                {!isGenerating && aiGeneratedPalette && (
                  <div className="space-y-6">
                    {/* Palette Information */}
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-[10px] uppercase font-mono tracking-wider font-semibold px-2 py-0.5 bg-indigo-500/20 text-indigo-300 rounded border border-indigo-500/10">
                          {aiGeneratedPalette.relationshipType}
                        </span>
                        <span className="text-[10px] font-mono text-slate-400">
                          Base: {aiGeneratedPalette.baseColor}
                        </span>
                      </div>
                      <h4 className="text-xl font-bold text-white tracking-tight">{aiGeneratedPalette.paletteName}</h4>
                    </div>

                    {/* Color blocks stack */}
                    <div className="flex rounded-xl overflow-hidden border border-white/10 h-32">
                      {/* Original Base Color Stop */}
                      <div
                        onClick={() => copyText(aiGeneratedPalette.baseColor, `Base Hex: ${aiGeneratedPalette.baseColor}`)}
                        style={{ backgroundColor: aiGeneratedPalette.baseColor }}
                        className="h-full flex-1 flex flex-col justify-end items-center p-2 cursor-pointer hover:flex-[1.5] transition-all relative group"
                        title="Click to copy hex"
                      >
                        <span className="text-[9px] font-bold text-black bg-white px-1 rounded shadow-sm opacity-20 group-hover:opacity-100 transition">
                          BASE
                        </span>
                        <span className="text-[10px] font-mono text-black bg-white/80 backdrop-blur-md px-1 rounded font-bold mt-1 opacity-0 group-hover:opacity-100 transition">
                          {aiGeneratedPalette.baseColor.toUpperCase()}
                        </span>
                      </div>

                      {/* Generated Related Colors */}
                      {aiGeneratedPalette.colors.map((hex, idx) => (
                        <div
                          key={`gen-${hex}-${idx}`}
                          onClick={() => copyText(hex, `Generated Hex: ${hex}`)}
                          style={{ backgroundColor: hex }}
                          className="h-full flex-1 flex flex-col justify-end items-center p-2 cursor-pointer hover:flex-[1.5] transition-all relative group"
                          title="Click to copy hex"
                        >
                          <span className="text-[9px] font-bold text-white bg-black/60 px-1 rounded shadow-sm opacity-20 group-hover:opacity-100 transition">
                            #{idx + 1}
                          </span>
                          <span className="text-[10px] font-mono text-white bg-black/75 backdrop-blur-md px-1 rounded font-bold mt-1 opacity-0 group-hover:opacity-100 transition">
                            {hex.toUpperCase()}
                          </span>
                        </div>
                      ))}
                    </div>

                    <p className="text-xs text-slate-400 font-mono text-center">
                      💡 Pro-Tip: Hover over color stops to reveal values. Click segment to copy!
                    </p>

                    {/* Palette actions */}
                    <div className="grid grid-cols-3 gap-2 border-t border-white/5 pt-4">
                      <button
                        onClick={() => {
                          const allColors = [aiGeneratedPalette.baseColor, ...aiGeneratedPalette.colors];
                          copyText(JSON.stringify(allColors), "JSON Array");
                        }}
                        className="text-xs py-2 bg-white/5 hover:bg-white/10 border border-white/10 text-slate-200 rounded-lg font-semibold flex items-center justify-center gap-1.5 transition"
                      >
                        <Copy className="w-3.5 h-3.5" />
                        Copy Array
                      </button>
                      <button
                        onClick={() => {
                          const paletteObj: PaletteItem = {
                            id: `ai-${Date.now()}`,
                            name: aiGeneratedPalette.paletteName,
                            colors: [aiGeneratedPalette.baseColor, ...aiGeneratedPalette.colors],
                            tags: ["AI-Crafted", aiGeneratedPalette.relationshipType.split(" ")[0]]
                          };
                          applyPaletteToSandbox(paletteObj);
                        }}
                        className="text-xs py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-semibold flex items-center justify-center gap-1.5 transition shadow-lg shadow-indigo-500/15"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        Preview UI
                      </button>
                      <button
                        onClick={() => {
                          const paletteObj: PaletteItem = {
                            id: `ai-${Date.now()}`,
                            name: aiGeneratedPalette.paletteName,
                            colors: [aiGeneratedPalette.baseColor, ...aiGeneratedPalette.colors],
                            tags: ["AI-Crafted", aiGeneratedPalette.relationshipType.split(" ")[0]]
                          };
                          setFavPalettes(prev => [...prev, paletteObj]);
                          triggerToast("Saved AI palette to Favorites!");
                        }}
                        className="text-xs py-2 bg-pink-500/10 hover:bg-pink-500/20 border border-pink-500/20 text-pink-300 rounded-lg font-semibold flex items-center justify-center gap-1.5 transition"
                      >
                        <Star className="w-3.5 h-3.5" />
                        Save Favorite
                      </button>
                    </div>

                  </div>
                )}

              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* CUSTOM FLOATING TOAST FEEDBACK MODAL */}
      <AnimatePresence>
        {showToast && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-6 right-6 bg-slate-900/90 text-white border border-white/10 backdrop-blur-xl rounded-xl px-5 py-3 shadow-2xl z-50 flex items-center gap-3"
          >
            <div className="w-5 h-5 rounded-full bg-indigo-500 flex items-center justify-center text-white font-bold shrink-0">
              ✓
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-200 font-sans">{toastMessage}</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
