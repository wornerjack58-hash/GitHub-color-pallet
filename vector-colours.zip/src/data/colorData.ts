export interface GradientItem {
  id: string;
  name: string;
  colors: [string, string];
  angle: number;
  tags: string[];
}

export interface PaletteItem {
  id: string;
  name: string;
  colors: string[];
  tags: string[];
}

// Beautiful hand-curated gradients for designers
export const PRESET_GRADIENTS: GradientItem[] = [
  { id: 'g-1', name: 'Tokyo Neon', colors: ['#f43f5e', '#8b5cf6'], angle: 135, tags: ['Neon', 'Sunset'] },
  { id: 'g-2', name: 'Pacific Blue', colors: ['#06b6d4', '#3b82f6'], angle: 135, tags: ['Ocean', 'Cool'] },
  { id: 'g-3', name: 'Matcha Latte', colors: ['#34d399', '#059669'], angle: 135, tags: ['Forest', 'Fresh'] },
  { id: 'g-4', name: 'Sunset Boulevard', colors: ['#f97316', '#ec4899'], angle: 135, tags: ['Sunset', 'Warm'] },
  { id: 'g-5', name: 'Lavender Haze', colors: ['#a78bfa', '#ec4899'], angle: 135, tags: ['Pastel', 'Warm'] },
  { id: 'g-6', name: 'Cyberpunk Red', colors: ['#ef4444', '#1e1b4b'], angle: 135, tags: ['Neon', 'Dark'] },
  { id: 'g-7', name: 'Sea Foam', colors: ['#6ee7b7', '#3b82f6'], angle: 135, tags: ['Ocean', 'Cool'] },
  { id: 'g-8', name: 'Pistachio Dream', colors: ['#a7f3d0', '#10b981'], angle: 135, tags: ['Pastel', 'Forest'] },
  { id: 'g-9', name: 'Solar Flares', colors: ['#eab308', '#f97316'], angle: 135, tags: ['Warm', 'Sunset'] },
  { id: 'g-10', name: 'Orchid Bloom', colors: ['#ec4899', '#8b5cf6'], angle: 135, tags: ['Pastel', 'Neon'] },
  { id: 'g-11', name: 'Midnight Deep', colors: ['#0f172a', '#1e293b'], angle: 135, tags: ['Minimal', 'Dark'] },
  { id: 'g-12', name: 'Cotton Candy', colors: ['#fbcfe8', '#bfdbfe'], angle: 135, tags: ['Pastel', 'Cool'] },
  { id: 'g-13', name: 'Northern Lights', colors: ['#059669', '#3b82f6'], angle: 135, tags: ['Forest', 'Ocean'] },
  { id: 'g-14', name: 'Vintage Rust', colors: ['#b45309', '#78350f'], angle: 135, tags: ['Vintage', 'Warm'] },
  { id: 'g-15', name: 'Ethereal Slate', colors: ['#64748b', '#cbd5e1'], angle: 135, tags: ['Minimal', 'Cool'] },
  { id: 'g-16', name: 'Neon Lime', colors: ['#84cc16', '#22c55e'], angle: 135, tags: ['Neon', 'Forest'] },
  { id: 'g-17', name: 'Crimson Velvet', colors: ['#991b1b', '#111827'], angle: 135, tags: ['Warm', 'Dark'] },
  { id: 'g-18', name: 'Apricot Whisper', colors: ['#ffedd5', '#fed7aa'], angle: 135, tags: ['Pastel', 'Warm'] },
  { id: 'g-19', name: 'Hyper Teal', colors: ['#0d9488', '#2563eb'], angle: 135, tags: ['Ocean', 'Neon'] },
  { id: 'g-20', name: 'Desert Oasis', colors: ['#f59e0b', '#10b981'], angle: 135, tags: ['Vintage', 'Forest'] },
];

// Beautiful hand-curated harmonized color combinations
export const PRESET_PALETTES: PaletteItem[] = [
  { id: 'p-1', name: 'Nordic Chill', colors: ['#2e3440', '#4c566a', '#88c0d0', '#eceff4'], tags: ['Minimal', 'Cool'] },
  { id: 'p-2', name: 'Cyber Neon', colors: ['#0f172a', '#f43f5e', '#3b82f6', '#10b981'], tags: ['Neon', 'Dark'] },
  { id: 'p-3', name: 'Warm Terrazzo', colors: ['#fca5a5', '#fecaca', '#fef08a', '#f97316'], tags: ['Warm', 'Pastel'] },
  { id: 'p-4', name: 'Botanical Garden', colors: ['#064e3b', '#047857', '#34d399', '#ecfdf5'], tags: ['Forest', 'Fresh'] },
  { id: 'p-5', name: 'Melancholy Vintage', colors: ['#57534e', '#78716c', '#d6d3d1', '#fafaf9'], tags: ['Vintage', 'Minimal'] },
  { id: 'p-6', name: 'Sweet Tangerine', colors: ['#ffedd5', '#fed7aa', '#f97316', '#ea580c'], tags: ['Sunset', 'Warm'] },
  { id: 'p-7', name: 'Deep Space', colors: ['#030712', '#111827', '#1f2937', '#e5e7eb'], tags: ['Dark', 'Minimal'] },
  { id: 'p-8', name: 'Strawberry Cream', colors: ['#ffebeb', '#ffc5c5', '#ff8484', '#e11d48'], tags: ['Pastel', 'Warm'] },
  { id: 'p-9', name: 'Malibu Sunset', colors: ['#1e1b4b', '#a21caf', '#db2777', '#f472b6'], tags: ['Sunset', 'Neon'] },
  { id: 'p-10', name: 'Sage & Slate', colors: ['#2f3e46', '#354f52', '#52796f', '#cad2c5'], tags: ['Forest', 'Minimal'] },
  { id: 'p-11', name: 'California Surf', colors: ['#0f4c5c', '#e36414', '#fb8b24', '#5f0f40'], tags: ['Vintage', 'Warm'] },
  { id: 'p-12', name: 'Candy Shop', colors: ['#ffd6ff', '#e7c6ff', '#c8b6ff', '#b8c0ff'], tags: ['Pastel', 'Cool'] },
  { id: 'p-13', name: 'Coffee Roasters', colors: ['#3b2219', '#634437', '#937060', '#decbca'], tags: ['Vintage', 'Warm'] },
  { id: 'p-14', name: 'Ocean Depths', colors: ['#0a192f', '#172a45', '#3066be', '#b4c5e4'], tags: ['Ocean', 'Cool'] },
  { id: 'p-15', name: 'Citrus Zest', colors: ['#fef9c3', '#fef08a', '#eab308', '#ca8a04'], tags: ['Warm', 'Fresh'] },
  { id: 'p-16', name: 'High-Tech Mint', colors: ['#0c4a6e', '#0284c7', '#38bdf8', '#f0f9ff'], tags: ['Ocean', 'Minimal'] },
  { id: 'p-17', name: 'Lofi Cozy', colors: ['#2c1a1d', '#4f3130', '#7a5c58', '#dcbfb3'], tags: ['Vintage', 'Warm'] },
  { id: 'p-18', name: 'Bubblegum', colors: ['#fecdd3', '#fda4af', '#f43f5e', '#be123c'], tags: ['Pastel', 'Warm'] },
  { id: 'p-19', name: 'Electric Velvet', colors: ['#311042', '#621055', '#b21f66', '#ff84ef'], tags: ['Neon', 'Sunset'] },
  { id: 'p-20', name: 'Urban Greenery', colors: ['#132a13', '#31572c', '#4f772d', '#90a955'], tags: ['Forest', 'Vintage'] },
];

// Aesthetic Adjectives to name generated items
const NAME_ADJECTIVES = [
  'Midnight', 'Ethereal', 'Satin', 'Electric', 'Velvet', 'Cosmic', 'Malibu', 'Boreal', 'Nordic', 'Tokyo',
  'Mystic', 'Liquid', 'Neon', 'Pastel', 'Cozy', 'Lofi', 'Minimalist', 'Smoky', 'Solar', 'Lunar', 'Arctic',
  'Vintage', 'Radiant', 'Silent', 'Golden', 'Vibrant', 'Calm', 'Warm', 'Holographic', 'Hyper', 'Pristine'
];

const NAME_NOUNS = [
  'Bloom', 'Whisper', 'Haze', 'Oasis', 'Drift', 'Pulse', 'Wave', 'Breeze', 'Glow', 'Flow', 'Shimmer',
  'Shadow', 'Vibe', 'Flame', 'Tide', 'Dream', 'Dawn', 'Dusk', 'Flares', 'Cove', 'Glacier', 'Forest',
  'Desert', 'Velvet', 'Symphony', 'Echo', 'Mirage', 'Aura', 'Horizon', 'Cascade', 'Slate', 'Sands'
];

// Helper to generate custom highly-aesthetic colors based on chosen styles
export function generateRandomAestheticColor(style?: string): string {
  if (style === 'Neon') {
    // Focus on pure bright saturated hues
    const h = Math.floor(Math.random() * 360);
    const s = 85 + Math.floor(Math.random() * 15); // 85% to 100%
    const l = 45 + Math.floor(Math.random() * 15); // 45% to 60%
    return hslToHex(h, s, l);
  } else if (style === 'Pastel') {
    // Soft desaturated light colors
    const h = Math.floor(Math.random() * 360);
    const s = 60 + Math.floor(Math.random() * 25); // 60% to 85%
    const l = 80 + Math.floor(Math.random() * 15); // 80% to 95%
    return hslToHex(h, s, l);
  } else if (style === 'Forest' || style === 'Fresh') {
    // Greens, sage, teal, olive
    const h = 80 + Math.floor(Math.random() * 90); // 80 to 170 (Greens to Teals)
    const s = 30 + Math.floor(Math.random() * 50);
    const l = 30 + Math.floor(Math.random() * 45);
    return hslToHex(h, s, l);
  } else if (style === 'Ocean' || style === 'Cool') {
    // Blues, cyans, teals
    const h = 180 + Math.floor(Math.random() * 70); // 180 to 250 (Cyan to Deep Blue)
    const s = 45 + Math.floor(Math.random() * 45);
    const l = 40 + Math.floor(Math.random() * 40);
    return hslToHex(h, s, l);
  } else if (style === 'Sunset' || style === 'Warm') {
    // Reds, oranges, pinks, gold
    const h = Math.random() > 0.5 ? Math.floor(Math.random() * 45) : 310 + Math.floor(Math.random() * 50);
    const s = 65 + Math.floor(Math.random() * 35);
    const l = 45 + Math.floor(Math.random() * 30);
    return hslToHex(h, s, l);
  } else if (style === 'Vintage') {
    // Desaturated cozy browns, warm gold, terracotta
    const h = 15 + Math.floor(Math.random() * 45); // 15 to 60
    const s = 25 + Math.floor(Math.random() * 30);
    const l = 35 + Math.floor(Math.random() * 35);
    return hslToHex(h, s, l);
  }

  // General random clean color
  const h = Math.floor(Math.random() * 360);
  const s = 50 + Math.floor(Math.random() * 40);
  const l = 40 + Math.floor(Math.random() * 40);
  return hslToHex(h, s, l);
}

// Named generators
export function generateRandomGradient(style?: string): GradientItem {
  const c1 = generateRandomAestheticColor(style);
  const c2 = generateRandomAestheticColor(style || 'Neon');
  const adjective = NAME_ADJECTIVES[Math.floor(Math.random() * NAME_ADJECTIVES.length)];
  const noun = NAME_NOUNS[Math.floor(Math.random() * NAME_NOUNS.length)];
  const id = `g-rnd-${Math.random().toString(36).substring(2, 9)}`;

  const categoryTags = style ? [style] : ['Custom'];
  if (style !== 'Minimal' && style !== 'Vintage') {
    categoryTags.push('Modern');
  }

  return {
    id,
    name: `${adjective} ${noun}`,
    colors: [c1, c2],
    angle: [45, 90, 135, 180, 225, 270, 315][Math.floor(Math.random() * 7)],
    tags: categoryTags
  };
}

export function generateRandomPalette(style?: string): PaletteItem {
  const size = 4;
  const colors: string[] = [];
  
  // Create beautiful harmonic sequence
  const baseStyle = style || ['Pastel', 'Warm', 'Cool', 'Vintage', 'Forest'][Math.floor(Math.random() * 5)];
  
  // We can pick a primary base color and generate variations
  const baseH = Math.floor(Math.random() * 360);
  
  for (let i = 0; i < size; i++) {
    if (Math.random() > 0.4) {
      colors.push(generateRandomAestheticColor(baseStyle));
    } else {
      // Harmonic offset (monochrome/analogous variation)
      const offsetH = (baseH + (i * 30)) % 360;
      let s = 60 + (i * 8);
      let l = 25 + (i * 15);
      if (baseStyle === 'Pastel') {
        s = 50 + (i * 5);
        l = 75 + (i * 5);
      } else if (baseStyle === 'Vintage') {
        s = 20 + (i * 6);
        l = 30 + (i * 10);
      }
      colors.push(hslToHex(offsetH, Math.min(100, s), Math.min(95, l)));
    }
  }

  const adjective = NAME_ADJECTIVES[Math.floor(Math.random() * NAME_ADJECTIVES.length)];
  const noun = NAME_NOUNS[Math.floor(Math.random() * NAME_NOUNS.length)];
  const id = `p-rnd-${Math.random().toString(36).substring(2, 9)}`;

  return {
    id,
    name: `${adjective} ${noun}`,
    colors,
    tags: [baseStyle]
  };
}

// Convert HSL to HEX
function hslToHex(h: number, s: number, l: number): string {
  l /= 100;
  const a = (s * Math.min(l, 1 - l)) / 100;
  const f = (n: number) => {
    const k = (n + h / 30) % 12;
    const color = l - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
    return Math.round(255 * color).toString(16).padStart(2, '0');
  };
  return `#${f(0)}${f(8)}${f(4)}`.toLowerCase();
}
